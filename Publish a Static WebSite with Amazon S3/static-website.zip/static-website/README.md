# Publish a Static WebSite with Amazon S3

Hi there! To get started, and deploy this static website using Amazon S3, visit https://aws-core-services.ws.kabits.com/static-website-with-s3/ for the tutorial.